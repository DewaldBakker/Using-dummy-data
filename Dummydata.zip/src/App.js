import './App.css';
import { useState, useEffect } from 'react';

function App() {
  const [user, setUser] = useState(null);
  const [fuser, setFUser] = useState(null);

  const [loadingUser, setLoadingUser] = useState(false);
  const [loadingFemale, setLoadingFemale] = useState(false);

  const [error, setError] = useState('');
  const [fetchCount, setFetchCount] = useState(0);

  const [nationality, setNationality] = useState('');

  async function getRandomUser() {
    try {
      setLoadingUser(true);
      setError('');

      const url = nationality
        ? `https://randomuser.me/api/?nat=${nationality}`
        : 'https://randomuser.me/api/';

      const resp = await fetch(url);
      if (!resp.ok) throw new Error('Failed to fetch user data');

      const data = await resp.json();
      if (!data.results || data.results.length === 0) {
        throw new Error('No user data returned');
      }

      setUser(data.results[0]);
      setFetchCount(prev => prev + 1);

    } catch (err) {
      const msg = err.message.toLowerCase();

      if (msg.includes('failed')) {
        setError('Unable to load a user profile. Try again later');
      } else {
        setError('Unknown error occurred');
      }

      setUser(null);

    } finally {
      setLoadingUser(false);
    }
  }

  async function getRandomFemaleUser() {
    try {
      setLoadingFemale(true);
      setError('');

      const url = nationality
        ? `https://randomuser.me/api/?gender=female&nat=${nationality}`
        : 'https://randomuser.me/api/?gender=female';

      const resp = await fetch(url);
      if (!resp.ok) throw new Error('Failed to fetch user data');

      const data = await resp.json();
      if (!data.results || data.results.length === 0) {
        throw new Error('No user data returned');
      }

      setFUser(data.results[0]);
      setFetchCount(prev => prev + 1);

    } catch (err) {
      const msg = err.message.toLowerCase();

      if (msg.includes('failed')) {
        setError('Unable to load female profile');
      } else {
        setError('Unknown error occurred');
      }

      setFUser(null);

    } finally {
      setLoadingFemale(false);
    }
  }

  useEffect(() => {
    getRandomUser();
    getRandomFemaleUser();
  }, []);

  return (
    <div className='app'>
      <div className='container'>

        <div className='dropdown'>
          <select
            value={nationality}
            onChange={(e) => setNationality(e.target.value)}
          >
            <option value="">All Nationalities</option>
            <option value="US">USA</option>
            <option value="GB">UK</option>
            <option value="CA">Canada</option>
            <option value="AU">Australia</option>
            <option value="ZA">South Africa</option>
            <option value="FR">France</option>
            <option value="DE">Germany</option>
          </select>
        </div>

        <div className='action'>
          <button onClick={getRandomUser} disabled={loadingUser}>
            {loadingUser ? 'Loading...' : 'Load Random User'}
          </button>

          <p className='fetch-count'>
            <strong>Profiles Loaded: {fetchCount}</strong>
          </p>

          {error && <p className='error-message'>{error}</p>}
        </div>

        {user && !loadingUser && (
          <div className='profile-card'>
            <img src={user.picture.large} alt="user" />
            <h2>{user.name.title} {user.name.first} {user.name.last}</h2>
            <p>Age: {user.dob.age}</p>
            <p>{user.phone}</p>
            <p>{user.email}</p>
            <p>{user.location.city}</p>
          </div>
        )}

        <button onClick={getRandomFemaleUser} disabled={loadingFemale}>
          {loadingFemale ? 'Loading...' : 'Load Female User'}
        </button>

        {fuser && !loadingFemale && (
          <div className='profile-card'>
            <img src={fuser.picture.large} alt="female user" />
            <h2>{fuser.name.title} {fuser.name.first} {fuser.name.last}</h2>
            <p>Age: {fuser.dob.age}</p>
            <p>{fuser.phone}</p>
            <p>{fuser.email}</p>
            <p>{fuser.location.city}</p>
          </div>
        )}

      </div>
    </div>
  );
}

export default App;